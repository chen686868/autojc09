1. 启动 sshd 服务：
script/start-sshd.sh

2. 临时重置 root 密码为 admin：
script/reset-password.sh
