#!/bin/sh
sleep 30
cd /home/root/r106
./r106 &
